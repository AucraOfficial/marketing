export default function Logo({ className = "h-10 w-auto" }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 500 500" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Pentagon Outline */}
      <path 
        d="M250 50L450 195V430H50V195L250 50Z" 
        stroke="#3a6700" 
        strokeWidth="24" 
        strokeLinejoin="round"
      />
      {/* Flower Center */}
      <circle cx="250" cy="260" r="30" fill="#3a6700" />
      {/* Flower Petals */}
      <circle cx="250" cy="180" r="45" stroke="#3a6700" strokeWidth="16" />
      <circle cx="325" cy="235" r="45" stroke="#3a6700" strokeWidth="16" />
      <circle cx="295" cy="325" r="45" stroke="#3a6700" strokeWidth="16" />
      <circle cx="205" cy="325" r="45" stroke="#3a6700" strokeWidth="16" />
      <circle cx="175" cy="235" r="45" stroke="#3a6700" strokeWidth="16" />
      {/* Connectors */}
      <path d="M250 210V230" stroke="#3a6700" strokeWidth="12" strokeLinecap="round" />
      <path d="M295 245L275 255" stroke="#3a6700" strokeWidth="12" strokeLinecap="round" />
      <path d="M275 295L265 280" stroke="#3a6700" strokeWidth="12" strokeLinecap="round" />
      <path d="M225 295L235 280" stroke="#3a6700" strokeWidth="12" strokeLinecap="round" />
      <path d="M205 245L225 255" stroke="#3a6700" strokeWidth="12" strokeLinecap="round" />
    </svg>
  );
}
